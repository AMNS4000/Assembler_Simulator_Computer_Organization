#----READING THE FILE----
import sys
f1=sys.stdin.read().splitlines()
list1=["0000000000000000"]*256
code=f1
for i in range(len(code)):
    list1[i]=code[i]
#print(list1)
PC_NO=0

basictemp="0"*16
def MEM():
    global PC_NO
    return(list1[PC_NO])
# print(MEMLIST,sep="\n")
haltline=0
for i in list1:
    if i[:5]=="01010":
        haltline=list1.index(i)

memory=[]
RF={"R0":"0"*16,"R1":"0"*16,"R2":"0"*16,"R3":"0"*16,"R4":"0"*16,"R5":"0"*16,"R6":"0"*16,"R7":"0"*16}
FLAGS=["0"]*16
def dtob(n):
    x=""
    while int(n)!=0:
        x+=str(int(n)%2)
        n=str(int(n)//2)
    return x[::-1]

def btod(n):
    x=n[::-1]
    s=0
    for i in range(len(n)):
        s+=(2**(i))*(int(x[i]))
    return s

def converttoreq(str4):
    indxdot=str4.find('.')
    str1=str4[:indxdot]
    str2=str4[indxdot+1:]
    str5=dtob(str1)
    str6=dtob2("."+str2)
    exponent=len(str5)-1
    strexp=dtob(str(exponent))
    if (len(strexp)<3):
        strexp="0"*(3-len(strexp))+strexp
    mantisa=str5[1:]+str6
    if (len(mantisa)!=5):
        mantisa+="0"*(5-len(mantisa))
    finalstr=strexp+mantisa
    return finalstr
def dtob2(n):
    x=""
    temp=""
    flag=0
    while (flag!=1):
        temp=2*(float(n))
        posdot=str(temp).find('.')
        x+=str(temp)[:posdot]
        if (float(temp)==int(temp)):
            flag=1
            return x
        else:
            n="."+str(temp)[posdot+1:]

def addition(reg1, reg2, reg3):
    
    global PC_NO
    val1=btod(RF[str(reg1)])
    val2=btod(RF[str(reg2)])
    if (val1+val2>2**16-1):
        str3=dtob(val1+val2)
        RF[str(reg3)]=str3[1:]
        RF["R7"]="0000000000001000"
    else:
        str3=dtob(val1+val2)
        if (len(str3)==16):
            RF[str(reg3)]=str3
        elif (len(str3)!=16):
            RF[str(reg3)]="0"*(16-len(str3))+str3
        RF["R7"]="0000000000000000"
    PC_NO+=1        
    
def subtraction(reg1, reg2, reg3):
    global PC_NO
    val1=btod(RF[str(reg1)])
    val2=btod(RF[str(reg2)])
    if (val1<val2):
        RF["R7"]="0000000000001000"
        RF["R3"]="0"*16
    else:
        str3=dtob(val1-val2)
        if (len(str3)==16):
            RF[str(reg3)]=str3
        elif (len(str3)!=16):
            RF[str(reg3)]="0"*(16-len(str3))+str3
        RF["R7"]="0000000000000000"
    PC_NO+=1

def multiplication(reg1, reg2, reg3):
    global PC_NO
    val1=int(btod(RF[str(reg1)]))
    val2=int(btod(RF[str(reg2)]))
    if (val1*val2>2**16-1):
        RF["R7"]="0000000000001000"
        str3=dtob(val1*val2)
        RF["R3"]=str3[len(str3)-16:]
    else:
        str3=dtob(val1*val2)
        if (len(str3)==16):
            RF[str(reg3)]=str3
        elif (len(str3)!=16):
            RF[str(reg3)]="0"*(16-len(str3))+str3
        RF["R7"]="0000000000000000"
    PC_NO+=1

def moveimmediate(reg1,val):
    global PC_NO
    RF[str(reg1)]="0"*8+val
    RF["R7"]="0000000000000000"
    PC_NO+=1
def moveregister(reg1,reg2):
    global PC_NO
    RF[str(reg2)]=RF[str(reg1)]
    RF["R7"]="0000000000000000"
    PC_NO+=1

def Load(reg1,mem_addr):
    global PC_NO,mnum
    RF[str(reg1)]=list1[mem_addr]
    RF["R7"]="0000000000000000"
    PC_NO+=1


def Store(reg1,mem_addr):
    global PC_NO
    list1[mem_addr]=RF[str(reg1)]
    PC_NO+=1
    RF["R7"]="0000000000000000"
    
def jumpless(mem):
    global PC_NO
    if (RF["R7"][-3]=="1"):
        if (btod(mem)>haltline):
            # print("halt passed")
            return 0
        else:   
            PC_NO=btod(mem)
            RF["R7"]=basictemp
            return 1
    else:
        PC_NO+=1
        RF["R7"]=basictemp
        return 1

def jumpequal(mem):
    global PC_NO
    if (RF["R7"][-1]=="1"):
        if (btod(mem)>haltline):
            # print("halt passed")
            return 0
        else:   
            PC_NO=btod(mem)
            RF["R7"]=basictemp
            return 1
    else:
        PC_NO+=1
        RF["R7"]=basictemp
        return 1

def jumpgreat(mem):
    global PC_NO
    if (RF["R7"][-2]=="1"):
        if (btod(mem)>haltline):
            # print("halt passed")
            return 0
        else:   
            PC_NO=btod(mem)
            RF["R7"]=basictemp
            return 1
    else:
        PC_NO+=1
        RF["R7"]=basictemp
        return 1
    

def unconditional_jump(mem):
    global PC_NO
    # print("mem=",mem)

    if (btod(mem)>haltline):
        # print("halt passed")
        return 0
    else:   
        PC_NO=btod(mem)
        RF["R7"]=basictemp
        return 1

def INV(R1,R2):
    global PC_NO
    Rx=RF[str(R1)]
    strn=""
    for i in Rx:
        if i=="0":
            strn+="1"
        else:
            strn+="0"
    RF[str(R2)]=strn
    PC_NO+=1
    RF["R7"]="0000000000000000"

def AND(R1,R2,R3):
    global PC_NO
    strn=""
    # print("\n",R3,RF[str(R3)],"\n")
    temp1=RF[str(R1)]
    temp2=RF[str(R2)]
    for i in range(0,16):
        strn+=str(int(temp1[i])&int(temp2[i]))
    RF[str(R3)]=strn
    # print("\n",R3,strn,RF[str(R3)],"\n")
    PC_NO+=1
    RF["R7"]="0000000000000000"

def OR(R1,R2,R3):
    global PC_NO
    strn=""
    temp1=RF[str(R1)]
    temp2=RF[str(R2)]
    for i in range(0,16):
        strn+=str(int(temp1[i])|int(temp2[i]))
    RF[str(R3)]=strn
    PC_NO+=1
    RF["R7"]="0000000000000000"
    

def XOR(R1,R2,R3):
    global PC_NO
    strn=""
    temp1=RF[str(R1)]
    temp2=RF[str(R2)]
    for i in range(0,16):
        strn+=str(int(temp1[i])^int(temp2[i]))
    RF[str(R3)]=strn
    PC_NO+=1
    RF["R7"]="0000000000000000"

def left_shift(R1,imm):
    global PC_NO
    temp=RF[str(R1)]
    n=btod(imm)
    temp2=temp[n:]+"0"*n
    RF[str(R1)]=temp2
    PC_NO+=1
    RF["R7"]="0000000000000000"



def right_shift(R1,imm):
    global PC_NO
    temp=RF[str(R1)]
    n=btod(imm)
    if (n<17):
        temp2="0"*n+temp[0:16-n]
        RF[str(R1)]=temp2
    else:
        RF[str(R1)]="0"*16
    PC_NO+=1
    RF["R7"]="0000000000000000"

def divide(R3,R4):
    global PC_NO
    x=btod(RF[str(R3)])
    y=btod(RF[str(R4)])
    temp=dtob(x//y)
    temp="0"*(16-len(temp))+temp
    RF["R0"]=temp
    temp=dtob(x%y)
    temp="0"*(16-len(temp))+temp
    RF["R1"]=temp
    PC_NO+=1
    RF["R7"]="0000000000000000"


def compare(reg1,reg2):
    # RF["R7"]=basictemp
    # print("RF==",RF["R7"])
    global PC_NO
    if (RF[str(reg1)]>RF[str(reg2)]):
        RF["R7"]="0000000000000010"
    elif (RF[str(reg1)]<RF[str(reg2)]):
        RF["R7"]="0000000000000100"
    elif (RF[str(reg1)]==RF[str(reg2)]):
        RF["R7"]="0000000000000001"
    PC_NO+=1
    
def addf(reg1,reg2,reg3):
    global PC_NO,halted
    if (CTD(RF[str(reg1)])+CTD(RF[str(reg2)])>=253):
        RF["R7"]="000000000001000"
        halted=True
        RF[str(reg3)]="0000000011111111"
    else:
        RF[str(reg3)]="0"*8+converttoreq(str(CTD(RF[str(reg1)])+CTD(RF[str(reg2)])))
        PC_NO+=1



def subf(reg1,reg2,reg3):
    global PC_NO,halted
    if (CTD(RF[str(reg1)])-CTD(RF[str(reg2)])<1):
        RF["R7"]="0000000000001000"
        halted=True
        RF[str(reg3)]="0000000000000000"
    else:

        # print(CTD(RF[str(reg1)]),CTD(RF[str(reg2)]),CTD(RF[str(reg1)])-CTD(RF[str(reg2)]))
        RF[str(reg3)]="0"*8+converttoreq(str(CTD(RF[str(reg1)])-CTD(RF[str(reg2)])))
        PC_NO+=1
halted=False


def movf(reg1,imm):
    global PC_NO,halted
    if (0<imm<=32.55):
        RF[str(reg1)]="00000000"+converttoreq(imm)
        PC_NO+=1
    else:
        halted=True
def CTD(str2):
    str2=str2[8:]
    str3=["1","."]
    str4=[]
    for i in str2[3:]:
        str3.append(i)
    str3=str3+str4
    n=btod(str2[:3])
    for i in range(n):
        temp=str3[i+1]
        str3[i+1]=str3[i+2]
        str3[i+2]=temp
    str3=chntd(str3)
    return float(str3)

def chntd(str1):
    string5=""
    for i in str1:
        string5+=str(i)
    a,b=string5.split(".")
    a=str(btod(a))
    b=decbtod(b)
    return int(a)+float(b)

def decbtod(a):
    num=0
    for i in range (1,len(a)+1):
        num+=int(a[i-1])*(2**(-i))
    return str(num)

halted=False

def EE(instruction):
    global halted
    code=instruction[:5]
    if (code=="10000"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        addition(R1,R2,R3)
    elif(code=="10001"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        subtraction(R1,R2,R3)
    elif(code=="10010"):
        R1="R"+str(btod(instruction[5:8]))
        imm=instruction[8:16]
        moveimmediate(R1,imm)
    elif(code=="10011"):
        R1="R"+str(btod(instruction[10:13]))
        R2="R"+str(btod(instruction[13:16]))
        moveregister(R1,R2)
    elif(code=="10100"):
        R1="R"+str(btod(instruction[5:8]))
        memadress=btod(instruction[8:16])
        Load(R1,memadress)
    elif(code=="10101"):
        R1="R"+str(btod(instruction[5:8]))
        memadress=btod(instruction[8:16])
        Store(R1,memadress)
    elif(code=="10110"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        multiplication(R1,R2,R3)
    elif(code=="10111"):
        R1="R"+str(btod(instruction[10:13]))
        R2="R"+str(btod(instruction[13:16]))
        divide(R1,R2)
    elif(code=="11000"):
        R1="R"+str(btod(instruction[5:8]))
        imm=instruction[8:16]
        right_shift(R1,imm)
    elif(code=="11001"):
        R1="R"+str(btod(instruction[5:8]))
        imm=instruction[8:16]
        left_shift(R1,imm)
    elif(code=="11010"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        XOR(R1,R2,R3)
    elif(code=="11011"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        OR(R1,R2,R3)
    elif(code=="11100"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        AND(R1,R2,R3)
    elif(code=="11101"):
        R1="R"+str(btod(instruction[10:13]))
        R2="R"+str(btod(instruction[13:16]))
        INV(R1,R2)
    elif(code=="11110"):
        R1="R"+str(btod(instruction[10:13]))
        R2="R"+str(btod(instruction[13:16]))
        compare(R1,R2)
    elif(code=="11111"):
        memadress=instruction[8:16]
        if (unconditional_jump(memadress)==0):
            halted=True
    elif(code=="01100"):
        memadress=instruction[8:16]
        if (jumpless(memadress)==0):
            halted=True
    elif(code=="01101"):
        memadress=instruction[8:16]
        if (jumpgreat(memadress)==0):
            halted=True
    elif(code=="01111"):
        memadress=instruction[8:16]
        if (jumpequal(memadress)==0):
            halted=True
    elif(code=="00000"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        addf(R1,R2,R3)
    elif(code=="00001"):
        R1="R"+str(btod(instruction[7:10]))
        R2="R"+str(btod(instruction[10:13]))
        R3="R"+str(btod(instruction[13:16]))
        subf(R1,R2,R3)
    elif(code=="00010"):
        R1="R"+str(btod(instruction[5:8]))
        imm=instruction[8:16]
        moveimmediate(R1,imm)
    elif(code=="01010"):
        halted=True
    else:
        halted=True
    # PC_NO=str(int(PC_NO)+1)
    return 


while (not halted):
    instruction=MEM()
    str_PC=dtob(PC_NO)
    
    # print(PC_NO,end=" ")
    if (len(str_PC)==8):
        print(str_PC,end=" ")
    else:
        print("0"*(8-len(str_PC))+str_PC,end=" ") 
    EE(instruction)
    for i in RF.values():
        print(i,end=" ")
    print(" ")
for i in list1:
    print(i,end="\n")
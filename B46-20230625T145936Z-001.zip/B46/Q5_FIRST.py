a=input("Enter the space in the memory :")
print("Bit Addressable Memory\nNibble Addressable Memory\nByte Addressable Memory\n")
b=input("Enter how the memory is addressed (one from above) :")
if b=="Bit Addressable Memory":
    cell=1
    size=0
elif b=="Nibble Addressable Memory":
    cell=4
    size=2
elif b=="Byte Addressable Memory":
    cell=8
    size=3    
else:
    print("Wrong Input")
len_ins=input("Enter the length of one instructions in bit")
len_r=input("Enter the length of register in bit")
def con(c):
    count=0
    while True:
        ques=c/2
        if c%2!=0:
            if count==0:
                break
            else:
                print("wrong input")
                exit()
        count+=1
        c=ques
        if ques==1:
            break
    return(count)

if a[-2:]=="MB":
    count=con(int(a[:-2]))
    memo=23+count
elif a[-2:]=="B":
    count=con(int(a[:-1]))
    memo=3+count
elif a[-2:]=="kB":
    count=con(int(a[:-2]))
    memo=13+count
elif a[-2:]=="Mb":
    count=con(int(a[:-2]))
    memo=20+count
elif a[-2:]=="GB":
    count=con(int(a[:-2]))    
    memo=33+count
elif a[-2:]=="bit":
    count=con(int(a[:-3]))
    memo=count
else:
    print("Wrong Input")
    exit()
p=memo-size
print("Minimum bits that are needed to represent an address in this architecture are : ",p)
opcode_size=int(len_ins[:-3])-(int(len_r[:-3])+p)
print("Number of bits needed by opcode :",opcode_size)

filler_bits=int(len_ins[:-3])-2*(int(len_r[:-3]))-opcode_size
print("Number of filler bits :",filler_bits)
print("Maximum number of instrucrtions this ISA can support :",2**opcode_size)
register=int(len_r[:-3])
print("Maximum number of registers this ISA can support :",2**register)





